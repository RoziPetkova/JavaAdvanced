package interfaces;
public interface Target {
    void receiveDamage(int dmg);
    boolean isDead();
}
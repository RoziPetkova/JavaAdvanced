package loggers;

public class EventLogger {

}

package e1013infernoInfinity.commands;

public interface Executable {

	String execute();
}

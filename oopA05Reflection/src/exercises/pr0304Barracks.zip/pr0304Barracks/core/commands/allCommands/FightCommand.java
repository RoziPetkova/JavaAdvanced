package exercises.pr0304Barracks.core.commands.allCommands;

import exercises.pr0304Barracks.core.commands.Command;

public class FightCommand extends Command{


	@Override
	public String execute() {
		return "fight";
	}
}

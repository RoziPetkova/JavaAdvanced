package exercises.pr0304Barracks.contracts;

public class NotImplementedException {

}

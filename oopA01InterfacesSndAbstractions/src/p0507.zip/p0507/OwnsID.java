package p0507;

public interface OwnsID {
	
	boolean corectID(String number);
}

package p0507;

public interface Buyer {
	void buyFood();

	int getFoodAmmound();
}

package p0507;

public interface Person {
	
	public int getAge();
	public String getName();
}

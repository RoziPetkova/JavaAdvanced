package p0507;

public class Pet extends Birthable {

	public Pet(String bitrhDay) {
		super(bitrhDay);
	}
}

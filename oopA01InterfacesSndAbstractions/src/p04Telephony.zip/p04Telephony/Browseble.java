package p04Telephony;

import java.util.List;

public interface Browseble {
	void brows(List<String> list);
}

package p04Telephony;

import java.util.List;

public interface Callable {
	void call(List<String> list);
}

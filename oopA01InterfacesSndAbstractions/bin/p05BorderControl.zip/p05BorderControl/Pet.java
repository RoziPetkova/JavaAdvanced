package p05BorderControl;

public class Pet extends Birthable {

	public Pet(String bitrhDay) {
		super(bitrhDay);
	}
}

package p05BorderControl;

public interface OwnsID {
	
	boolean corectID(String number);
}

package p05BorderControl;


public class Citizen extends Birthable implements OwnsID {
	
	private String id;
	
	public Citizen(String bitrhDay) {
		super(bitrhDay);
	}

	public String getId() {
		return id;
	}
	@Override
	public boolean corectID(String number) {
		return id.endsWith(number); 
	}

	
}
